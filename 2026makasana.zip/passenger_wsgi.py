"""
WSGI entry for Phusion Passenger (cPanel).

Set FLASK_CONFIG=production before import, or rely on the default below.
The application root on the server should be the directory that contains
this file, `run.py`, and the `app` package.
"""
import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

os.environ.setdefault("FLASK_CONFIG", "production")

from app import create_app

application = create_app()
